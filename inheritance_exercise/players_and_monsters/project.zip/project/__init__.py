def food():
    return None